"""Pinned, offline vLLM adapter for CUDA development pilots."""

from __future__ import annotations

from hashlib import sha256
from pathlib import Path
from time import monotonic

from .runner import Generation


class LocalVLLMBackend:
    def __init__(self, snapshot: Path) -> None:
        from vllm import LLM

        if not snapshot.is_dir() or not (snapshot / "config.json").is_file():
            raise ValueError("model snapshot must be an existing local directory")
        self.llm = LLM(
            model=str(snapshot), trust_remote_code=False,
            dtype="auto", max_model_len=4096, gpu_memory_utilization=0.82,
            enforce_eager=True,
        )
        self.tokenizer = self.llm.get_tokenizer()

    def generate(self, prompt: str, max_new_tokens: int) -> Generation:
        from vllm import SamplingParams
        from vllm.sampling_params import GuidedDecodingParams

        rendered = self.tokenizer.apply_chat_template(
            [{"role": "user", "content": prompt}],
            add_generation_prompt=True, tokenize=False,
            enable_thinking=False,
        )
        seed = int.from_bytes(sha256(prompt.encode()).digest()[:4], "big")
        settings = SamplingParams(
            temperature=0.7, top_p=0.8, top_k=20,
            max_tokens=max_new_tokens, seed=seed,
            guided_decoding=GuidedDecodingParams(json_object=True),
        )
        started = monotonic()
        response = self.llm.generate([rendered], sampling_params=settings,
                                     use_tqdm=False)[0]
        completion = response.outputs[0]
        return Generation(completion.text, len(response.prompt_token_ids),
                          len(completion.token_ids), monotonic() - started)
